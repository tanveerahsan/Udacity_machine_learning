
File list-

1. Proposal - Capstone Project proposal
2. Sample Data file-capstone_recharge_sample.csv