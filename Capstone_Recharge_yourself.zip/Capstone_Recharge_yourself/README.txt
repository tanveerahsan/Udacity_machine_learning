Required Software:

Python 2.7
Jupyter Notebook
SKLearn
numpy
panda
matplotlib


The following files are required to run the code-

1. Capstone_Recharge Yourself.ipynb
2. recharge.csv
3. visuals.py
4. visuals.pyc



PDF Reports-
1. Project Proposal-Proposal.pdf
2. Project Report-Capstone Project Report_Recharge_Yourself.pdf



